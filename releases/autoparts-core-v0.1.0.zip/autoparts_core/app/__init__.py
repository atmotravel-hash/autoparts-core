"""Streamlit application helpers."""
